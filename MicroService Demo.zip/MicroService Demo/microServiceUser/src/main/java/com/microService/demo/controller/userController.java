package com.microService.demo.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.microService.demo.Entity.userEntity;
import com.microService.demo.VO.responseTemplateVO;
import com.microService.demo.service.userService;


@RestController
public class userController {
	
	@Autowired
	private userService service;
	
	@GetMapping("/user")
	public List<userEntity> getAll() {
		return service.getAll();
	}
	
	@GetMapping("/user/{id}")
	public responseTemplateVO getId(@PathVariable int id) {
		return service.getById(id);
	}
	
	@PostMapping("/user")
	public userEntity saveUser(@RequestBody userEntity e1) {
		return service.saveUser(e1);
	}
}
