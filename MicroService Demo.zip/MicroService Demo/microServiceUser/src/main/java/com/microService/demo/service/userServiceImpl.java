package com.microService.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.microService.demo.Entity.userEntity;
import com.microService.demo.VO.department;
import com.microService.demo.VO.responseTemplateVO;
import com.microService.demo.dao.userRepositoy;

@Service
public class userServiceImpl implements userService{
	
	@Autowired
	private userRepositoy repo;
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Override
	public List<userEntity> getAll() {
		return repo.findAll();
	}

	@Override
	public userEntity saveUser(userEntity e1) {
		return repo.save(e1);
	}

	@Override
	public responseTemplateVO getById(int id) {
		userEntity user = repo.findById(id).get();
		String i = String.valueOf(id);
		department dep = restTemplate.getForObject("http://DEPARTMENT-SERVICE/departments/"+ i, department.class);
		
		responseTemplateVO re = new responseTemplateVO();
		re.setUser(user);
		re.setDepartment(dep);
		return re;
	}
	
	
}
