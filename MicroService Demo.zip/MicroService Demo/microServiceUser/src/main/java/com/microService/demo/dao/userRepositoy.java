package com.microService.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.microService.demo.Entity.userEntity;

public interface userRepositoy extends JpaRepository<userEntity, Integer>{

}
