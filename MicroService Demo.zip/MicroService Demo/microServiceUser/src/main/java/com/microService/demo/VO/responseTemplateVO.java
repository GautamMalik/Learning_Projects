package com.microService.demo.VO;

import com.microService.demo.Entity.userEntity;

public class responseTemplateVO {
	
	private userEntity user;
	private department department;
	public responseTemplateVO(userEntity user, com.microService.demo.VO.department department) {
		super();
		this.user = user;
		this.department = department;
	}
	@Override
	public String toString() {
		return "responseTemplateVO [user=" + user + ", department=" + department + "]";
	}
	public responseTemplateVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public userEntity getUser() {
		return user;
	}
	public void setUser(userEntity user) {
		this.user = user;
	}
	public department getDepartment() {
		return department;
	}
	public void setDepartment(department department) {
		this.department = department;
	}
	
}
