package com.microService.demo.service;

import java.util.List;

import com.microService.demo.Entity.userEntity;
import com.microService.demo.VO.responseTemplateVO;

public interface userService {
	public List<userEntity> getAll();
	
	public userEntity saveUser(userEntity e1);

	public responseTemplateVO getById(int id);
}
