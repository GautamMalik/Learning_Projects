package com.microServiceDeaprtment.demo.service;

import java.util.List;

import com.microServiceDeaprtment.demo.entity.departmentEntity;

public interface departmentService {
	
	public departmentEntity getById(int id);
	
	public List<departmentEntity> getAllDepartment();
	
	public departmentEntity saveDepartment(departmentEntity e1);
}
