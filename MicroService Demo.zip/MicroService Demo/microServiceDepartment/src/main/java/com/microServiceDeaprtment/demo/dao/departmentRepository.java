package com.microServiceDeaprtment.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.microServiceDeaprtment.demo.entity.departmentEntity;


public interface departmentRepository extends JpaRepository<departmentEntity, Integer>{
	
}
