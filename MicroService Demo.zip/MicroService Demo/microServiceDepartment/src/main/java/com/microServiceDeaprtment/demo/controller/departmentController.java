package com.microServiceDeaprtment.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.microServiceDeaprtment.demo.entity.departmentEntity;
import com.microServiceDeaprtment.demo.service.departmentService;

@RestController
public class departmentController {
	
	@Autowired
	private departmentService service;
	
	@GetMapping("/departments")
	public List<departmentEntity> getAll() {
		return service.getAllDepartment();
	}
	
	
	@GetMapping("/departments/{id}")
	public departmentEntity getbyId(@PathVariable int id) {
		return service.getById(id);
	}
	
	@PostMapping("/departments")
	public departmentEntity save(@RequestBody departmentEntity e1) {
		return service.saveDepartment(e1);
	}
}
