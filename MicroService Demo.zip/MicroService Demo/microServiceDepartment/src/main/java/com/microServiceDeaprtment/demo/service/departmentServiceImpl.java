package com.microServiceDeaprtment.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.microServiceDeaprtment.demo.dao.departmentRepository;
import com.microServiceDeaprtment.demo.entity.departmentEntity;

@Service
public class departmentServiceImpl implements departmentService{
	
	@Autowired
	private departmentRepository repo;
	
	@Override
	public departmentEntity getById(int id) {
		return repo.findById(id).get();
	}

	@Override
	public List<departmentEntity> getAllDepartment() {
		return repo.findAll();
	}

	@Override
	public departmentEntity saveDepartment(departmentEntity e1) {
		return repo.save(e1);
	}
}
