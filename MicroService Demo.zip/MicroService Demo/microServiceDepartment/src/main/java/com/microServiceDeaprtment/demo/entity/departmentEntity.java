package com.microServiceDeaprtment.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "department")
public class departmentEntity {
	@Id
	@Column(name = "department_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(name = "department_name",length = 50)
	private String name;
	
	@Column(name = "department_address",length = 50)
	private String address;
	
	@Column(name = "department_code",length = 50)
	private String code;
	
	

	public departmentEntity(int id, String name, String address, String code) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
		this.code = code;
	}

	public departmentEntity() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	@Override
	public String toString() {
		return "department [id=" + id + ", name=" + name + ", address=" + address + ", code=" + code + "]";
	}
	
}
